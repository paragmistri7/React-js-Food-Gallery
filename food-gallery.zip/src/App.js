import Foodgallery from "./component/foodgallery "

const App =() => {
  return (
    <>
    <Foodgallery/>
    </>
  )
}
export default App